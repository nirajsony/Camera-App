package com.example.pulsescanner;

import android.Manifest;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.os.Environment.getExternalStoragePublicDirectory;

public class SecondActivity extends AppCompatActivity {

    String stPathoftheFile;
    ImageView imgView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        if(Build.VERSION.SDK_INT > 23){

            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);

        }

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    public void backtoHome(View view){

        Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if(takePicture.resolveActivity(getPackageManager()) !=null){

            File photoFile = null;
            photoFile = createPhotoFile();

            if(photoFile!=null){

                stPathoftheFile = photoFile.getAbsolutePath();

                Uri loPhtouri = FileProvider.getUriForFile(this, "com.example.pulsescanner.fileprovider", photoFile);
                takePicture.putExtra(MediaStore.EXTRA_OUTPUT, loPhtouri);
                startActivityForResult(takePicture, 1);

            }

        }

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK)
        {
            if(resultCode==1){

                Bitmap bit = BitmapFactory.decodeFile(stPathoftheFile);
                imgView.setImageBitmap(bit);

            }
        }
    }


    public void btnOpenCameraClick(){


    }



    public File createPhotoFile(){

        String name  = new SimpleDateFormat("dd-mm-yyyy").format(new Date());

        File stStorageDirectory = getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = null;
        try{
             image = File.createTempFile(name, ".jpg", stStorageDirectory);
        }
        catch(IOException ex){

            Log.d("myLog", ex.getMessage());
        }

        return image;

    }

}
